var colors = ['rgb(251,67,99)','rgb(255,173,97)','rgb(255,232,87)','rgb(87,255,102)','rgb(87,96,255)','rgb(255,87,240)'];
var rand;

function setup() {
	createCanvas(400, 400);
	background(220);
	frameRate(5);
	noStroke();
}

function draw() {
	for(var x=10;x < 1000;x += 100) {
		for (var y=10;y < 1000;y += 100) {
			rand = int(random(6));
			fill(colors[rand]);
			ellipse(x,y,150,100);	
		}
	}		
}