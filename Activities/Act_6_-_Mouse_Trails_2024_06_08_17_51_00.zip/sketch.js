function setup() 
{
  createCanvas(400, 400);
  background(100);
}

function mouseDragged () { // Hold left-click to get a mouse trail
	
  let red = random(0, 200);
  let green = random(0, 0);
  let blue = random(0, 200);
	
  fill (red, green, blue); // Purple colour spectrum
  rect (mouseX, mouseY,20);
  ellipse (mouseX, mouseY,20); // Randomising shapes
}
