let img, masking;

function preload() {
  img = loadImage("gatism.jpg");

  masking = loadImage("blackpattern.png");
}

function setup() {
  createCanvas(1920, 1080);
  img.resize(1920, 1080);
  masking.resize(1920, 1080);
  noLoop();
}

function draw() {
  background(0, 0, 0);

  img.mask(masking);

  image(img, 0, 0);
}
