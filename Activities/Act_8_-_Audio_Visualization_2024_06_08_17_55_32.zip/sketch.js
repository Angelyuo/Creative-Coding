var mic, fft; 

var colors = ['rgb(166,101,101)','rgb(82,86,137)','rgb(134,64,127)'];
var rand; // Colour randomizer

function setup() {
  createCanvas(400, 400);
  background(0);
  mic = new p5.AudioIn(); 
  mic.start(); 
  fft = new p5.FFT(); 
  background(220);

  noStroke();
}

function draw() {
  background(400, 400); 
  

  
  for(var x=10;x < 1000;x += 100) {
	for (var y=10;y < 1000;y += 100) {
		rand = int(random(3)); // Randomizes in three different colours
		fill(colors[rand]);
		rect(x,y,150,100); // Shape of the randomized blocks
	  }
  }
  
  var waveform = fft.waveform(); 
    stroke(255);
    strokeWeight(5); 
    noFill();
    beginShape()
  ;
  for (var i = 0; i < waveform.length; i++) {
    var x = map(i, 0, waveform.length, 0, width); 
    var y = map(waveform[i], -1, 1, 0, height);
    vertex(x, y); 
  }
  endShape();
  
  mic.connect();
}
