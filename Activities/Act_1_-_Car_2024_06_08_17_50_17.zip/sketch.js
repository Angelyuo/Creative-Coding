function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  fill (203, 148, 235)
  rect (50, 200, 300, 70) // Base of the car
  rect (50, 130, 200, 70) // Top of the car
  fill (203, 148, 255)
  rect (160, 140, 70, 130) // Front door
  rect (70, 140, 90, 130) // Back door
  fill (223, 247, 255)
  rect (165, 150, 60, 50) // Smaller window
  rect (75, 150, 80, 50) // Bigger window
  // rect (x, y, width, height)
  
  fill (37, 37, 37)
  ellipse (100, 270, 70, 70)
  ellipse (300, 270, 70, 70)
  
  }