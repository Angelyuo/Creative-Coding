var img;
function preload() 
{
img = loadImage("istockphoto-1131704553-612x612.jpg");
}

function setup() 
{
  createCanvas(400, 400);
  background(0);
}

function draw() 
{
  background(0);
  image(img,0,0);
  var v = map(mouseX,0,width,2,50);
  filter(POSTERIZE,v);
}