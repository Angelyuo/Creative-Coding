// Create a table
var table;
// Create an array to hold the particles
let particles = [];


function preload() {
    table = loadTable("My_Data.csv","csv");
}

function setup() {
  createCanvas(475,325);
  background(255);
	noStroke();
  
  // Create the particle array
  for (let i = 0; i < 100; i++) {
    particles.push(new Particle(random(width), random(height)));
  }
}

function draw() {
  
    // Draw the background particles
  for (let i = 0; i < particles.length; i++) {
    particles[i].display();
    particles[i].move();
  }
  
	push();
	textSize(20);
	textStyle(BOLD);
	text('My time spent on the computer', 95, 30);
    // Title
	textSize(14);
	textStyle(NORMAL);
    // Bar text and numbers
  
  translate(0,275);
  var data = table.getRow(1).arr;
  for(i = 0; i < table.getColumnCount(); i++) {
    var rectHeight = map(data[i], 98.6,101.2, 155, 157);
    translate(i + 50,0);
		lerpAm = map(data[i], 98.6,101.2, 0,1);
    var lerpCol = lerpColor(color(21, 110, 34),color(99, 15, 125),lerpAm); // Colour spectrum: Green = Low activity, Red = High activity
    
    fill(lerpCol);
		textAlign(CENTER);
    rect(0,0, 40,-rectHeight);
		text(data[i],20,-rectHeight - 10);
		fill(0);
		text(table.getRow(0).arr[i],20,20);
  }
	pop();
  

}

// Define a particle class with a constructor, display method, and move method
class Particle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-1, 1);
    this.vy = random(-1, 1);
    this.size = random(10, 30);
    this.color = color(random(100, 255), random(100, 255), random(100, 255), random(50, 150));
  }

  display() {
    noStroke();
    fill(this.color);
    ellipse(this.x, this.y, this.size, this.size);
  }

  move() {
    this.x += this.vx;
    this.y += this.vy;
    if (this.x < 0 || this.x > width) {
      this.vx *= -1;
    }
    if (this.y < 0 || this.y > height) {
      this.vy *= -1;
    }
  }
}
