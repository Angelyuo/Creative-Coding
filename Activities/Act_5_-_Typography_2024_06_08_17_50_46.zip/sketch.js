var word = "PAPYRUS"; 
var font


function preload() { 

font = loadFont("COMICSANSBOLD.TTF"); 
 } 

function setup() { 
  createCanvas(500, 200); 
  background(100); 
  
  textFont(font, 100); 
  textAlign(CENTER); 
  text(word, width/2, height/2);
 }